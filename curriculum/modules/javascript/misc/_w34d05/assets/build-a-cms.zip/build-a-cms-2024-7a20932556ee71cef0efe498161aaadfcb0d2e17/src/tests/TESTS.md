# BACKEND

## Test routing

  - When pathname is "" or "/" redirect user to the Home page
  - When pathname is "/admin" or "/admin/" redirect user to Login page (or...) 

# FRONTEND

# END-TO-END