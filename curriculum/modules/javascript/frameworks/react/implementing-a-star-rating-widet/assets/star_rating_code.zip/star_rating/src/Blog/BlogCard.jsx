import { Star } from "lucide-react"
import { useState } from "react";
import "./BlogCard.css"

function StarRating({ id, rating }) {

  const [currentRating, setCurrentRating] = useState(rating);

  const updateDBRating = (newRating, postId) => {
    // console.log({newRating});
    const URL = "http://localhost:3000/posts/" + postId;
    fetch(URL, {
      method: "PATCH",
      body: JSON.stringify({
        rating: newRating
      })
    })
      .then(res => res.json())
      .then(() => {
        setCurrentRating(newRating);
        console.log("Post rating updated!");
        // console.log(data);
      })
      .catch(error => {
        console.log(error);
      });
  }

  return (
    < div className="rating flex justify-center mt-4" >
      {
        [1, 2, 3, 4, 5].map(star => {
          let className = "";
          if (star <= currentRating) {
            className = "active";
          }
          return (
            <Star
              onClick={() => {
                let newRating = star;
                if (star === currentRating) {
                  newRating = 0;
                }
                // setCurrentRating(newRating);
                updateDBRating(newRating, id);
              }}
              key={star}
              className={className} />
          )
        })
      }
    </div >

  )
}

export default function BlogCard(props) {

  const { id, title, src, date, rating } = props.postData;

  return (
    <div className="lg:flex">
      <img className="object-cover w-full h-56 rounded-lg lg:w-64" src={src} alt="" />
      <div className="flex flex-col justify-between py-6 lg:mx-6">
        <a href="#" className="text-xl font-semibold text-gray-800 hover:underline dark:text-white ">
          {title}
        </a>
        <span className="text-sm text-gray-500 dark:text-gray-300 mt-4">On: {date}</span>
        <StarRating id={id} rating={rating} />
      </div>
    </div>

  )
}