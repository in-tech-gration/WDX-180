import './App.css'
import { useEffect, useState } from 'react';
import BlogCard from './Blog/BlogCard';

function App() {

  const [ posts, setPosts ] = useState([]);

  useEffect(function fetchPosts(){
    const URL = "http://localhost:3000/posts";
    fetch(URL)
    .then( res => res.json() )
    .then( posts =>{
      setPosts(posts);
    })
    .catch( error =>{
      // Showing a helpful descriptive message to the user
      console.log(error);
    })
  }, []);

  return (
    <section className="bg-white dark:bg-gray-900">
      <div className="container px-6 py-10 mx-auto">
        <h1 className="text-3xl font-semibold text-gray-800 capitalize lg:text-4xl dark:text-white">From the blog</h1>
        <div className="grid grid-cols-1 gap-8 mt-8 md:mt-16 md:grid-cols-2">

          {posts.map(post => {
            return (
              <BlogCard key={post.id} postData={post} />
            )
          })}

        </div>
      </div>
    </section>

  )
}

export default App
